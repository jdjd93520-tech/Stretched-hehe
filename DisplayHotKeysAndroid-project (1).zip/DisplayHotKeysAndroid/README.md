# Display HotKeys for Android

An Android Studio project that recreates the profile-oriented parts of the Windows **DisplayHotKeys** utility for Android phones (including connected external displays), within the limits of Android's public APIs.

## Current features

- Detects built-in, external, and virtual displays reported by `DisplayManager`.
- Lists each display's supported physical modes and refresh rates.
- Requests a preferred display mode for this app's own window on the built-in display.
- Can create a presentation on a selected external display and request a preferred mode for that presentation window.
- Saves up to 12 local profiles and reapplies them when the matching display is connected and the saved mode is still available.
- Supports `Ctrl + Alt + 1` through `Ctrl + Alt + 9` while the app has keyboard focus and a hardware keyboard is attached.
- Refreshes the display list when Android reports display connection or configuration changes.

## Important Android limitations

This is not a privileged system utility. Android's public SDK does **not** let an ordinary third-party app reproduce several Windows features globally:

- Change the device-wide logical resolution or density/DPI.
- Force another app or the whole system to use a selected refresh rate.
- Set system-wide scaling modes such as stretched, centered, or preserved.
- Force global screen orientation for all apps.
- Register global system-wide keyboard shortcuts.

`preferredDisplayModeId` is a request for the app's own window/presentation. The system, display hardware, power policy, and OEM implementation may ignore or constrain it. The app reports the modes Android exposes; it cannot guarantee a mode switch on every phone or dock. External display support varies by device and vendor.

## Build

1. Install Android Studio with Android SDK Platform 36 and a compatible Android Gradle Plugin toolchain.
2. Open this folder (`DisplayHotKeysAndroid`) in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

The project uses Java 17, `minSdk 26`, and `compileSdk 36`.

## Install and test

Install the debug APK on an Android phone. Connect an external display using a supported USB-C/HDMI adapter or wireless display path, then reopen the app. The external display should appear if Android exposes it through `DisplayManager`. Test mode requests carefully: only the app window/presentation is targeted, and the phone's system-wide display configuration is not modified.

## Relationship to the Windows project

The original project this Android port is based on conceptually is [jon-mil-92/DisplayHotKeys](https://github.com/jon-mil-92/DisplayHotKeys), a Windows-only utility. This Android project is a separate implementation and does not include or reuse its Windows executable.
