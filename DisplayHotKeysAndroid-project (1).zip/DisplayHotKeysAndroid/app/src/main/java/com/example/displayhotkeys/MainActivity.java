package com.example.displayhotkeys;

import android.app.Activity;
import android.app.Presentation;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "display_profiles";
    private static final int MAX_PROFILES = 12;
    private DisplayManager displayManager;
    private Spinner displaySpinner, modeSpinner;
    private TextView statusText, capabilityText, profileText;
    private LinearLayout profileContainer;
    private final List<Display> displays = new ArrayList<>();
    private final List<Display.Mode> modes = new ArrayList<>();
    private DisplayPresentation externalPresentation;
    private boolean updating;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        displayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        buildUi();
        refreshDisplays();
        displayManager.registerDisplayListener(displayListener, null);
    }

    @Override protected void onDestroy() {
        if (displayManager != null) displayManager.unregisterDisplayListener(displayListener);
        dismissPresentation();
        super.onDestroy();
    }

    private void buildUi() {
        int pad = dp(18);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF5F6FA);
        scroll.addView(root);

        TextView title = text("Display HotKeys", 27, true, 0xFF172033);
        root.addView(title);
        root.addView(text("Display profiles for Android phones and connected screens", 14, false, 0xFF5D6678));
        root.addView(space(18));

        section(root, "1 · Choose a display");
        displaySpinner = new Spinner(this);
        root.addView(displaySpinner, match());
        capabilityText = text("", 13, false, 0xFF5D6678);
        root.addView(capabilityText);
        root.addView(space(12));

        section(root, "2 · Choose a display mode");
        modeSpinner = new Spinner(this);
        root.addView(modeSpinner, match());
        root.addView(text("Modes are reported by Android and the device manufacturer. Applying a mode affects this app's window only; it does not change the phone's global display setting.", 13, false, 0xFF5D6678));
        Button apply = button("Apply to this app window");
        root.addView(apply, match());
        apply.setOnClickListener(v -> applySelectedMode());
        root.addView(space(12));

        section(root, "3 · Save profiles (up to 12)");
        Button save = button("Save current selection to a profile");
        root.addView(save, match());
        save.setOnClickListener(v -> saveProfile());
        profileText = text("Profiles are stored on this device.", 13, false, 0xFF5D6678);
        root.addView(profileText);
        profileContainer = new LinearLayout(this);
        profileContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(profileContainer);
        root.addView(space(14));

        section(root, "Keyboard shortcuts");
        root.addView(text("When this app is focused and a hardware keyboard is connected: Ctrl + Alt + 1–9 applies the matching saved profile. Android does not allow ordinary apps to register global system-wide hotkeys.", 13, false, 0xFF5D6678));
        root.addView(space(14));
        section(root, "Not available to ordinary Android apps");
        root.addView(text("Global DPI scaling, system-wide scaling modes (stretched / centered / preserved), forced system orientation, global hotkeys, and changing another app's display mode require privileged system or manufacturer-specific access. This app does not request root access or hide these limitations.", 13, false, 0xFF5D6678));
        root.addView(space(18));
        statusText = text("Ready", 13, true, 0xFF3457D5);
        root.addView(statusText);
        setContentView(scroll);

        displaySpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> loadModes(position)));
        modeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> updateModeStatus()));
    }

    private void refreshDisplays() {
        Display selected = selectedDisplay();
        displays.clear();
        Display[] found = displayManager.getDisplays();
        for (Display d : found) if (d.getState() != Display.STATE_UNKNOWN) displays.add(d);
        List<String> labels = new ArrayList<>();
        for (Display d : displays) {
            String kind = d.getDisplayId() == Display.DEFAULT_DISPLAY ? "Built-in" : "External / virtual";
            labels.add(kind + " · " + d.getName() + " (ID " + d.getDisplayId() + ")");
        }
        updating = true;
        displaySpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        int index = 0;
        if (selected != null) for (int i = 0; i < displays.size(); i++) if (displays.get(i).getDisplayId() == selected.getDisplayId()) index = i;
        if (!displays.isEmpty()) displaySpinner.setSelection(index);
        updating = false;
        loadModes(index);
        renderProfiles();
    }

    private void loadModes(int displayIndex) {
        if (updating || displayIndex < 0 || displayIndex >= displays.size()) return;
        Display d = displays.get(displayIndex);
        modes.clear();
        Display.Mode[] supported = d.getSupportedModes();
        if (supported != null) for (Display.Mode m : supported) modes.add(m);
        List<String> labels = new ArrayList<>();
        for (Display.Mode m : modes) labels.add(String.format(Locale.US, "%d × %d · %.2f Hz · mode %d", m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate(), m.getModeId()));
        modeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        int current = d.getMode().getModeId();
        for (int i = 0; i < modes.size(); i++) if (modes.get(i).getModeId() == current) modeSpinner.setSelection(i);
        boolean external = d.getDisplayId() != Display.DEFAULT_DISPLAY;
        capabilityText.setText((external ? "External display detected. " : "Built-in display selected. ") + modes.size() + " supported mode(s) reported by Android.");
        updateModeStatus();
    }

    private void applySelectedMode() {
        Display d = selectedDisplay();
        Display.Mode m = selectedMode();
        if (d == null || m == null) { toast("Select a display and mode first."); return; }
        if (d.getDisplayId() == Display.DEFAULT_DISPLAY) {
            setPreferredMode(getWindow(), m.getModeId());
            statusText.setText("Requested mode " + m.getModeId() + " for this app's built-in-display window.");
            toast("Mode requested for this app window");
        } else {
            try {
                if (externalPresentation == null || externalPresentation.getDisplay().getDisplayId() != d.getDisplayId()) {
                    dismissPresentation();
                    externalPresentation = new DisplayPresentation(this, d);
                    externalPresentation.show();
                }
                setPreferredMode(externalPresentation.getWindow(), m.getModeId());
                externalPresentation.setModeLabel(m);
                statusText.setText("Requested mode " + m.getModeId() + " for the app's presentation on " + d.getName() + ".");
                toast("Mode requested for external presentation");
            } catch (Exception e) {
                statusText.setText("Could not open a presentation on this display: " + e.getMessage());
            }
        }
    }

    private void setPreferredMode(Window window, int modeId) {
        if (window == null) return;
        WindowManager.LayoutParams attrs = window.getAttributes();
        attrs.preferredDisplayModeId = modeId;
        window.setAttributes(attrs);
    }

    private void saveProfile() {
        Display d = selectedDisplay(); Display.Mode m = selectedMode();
        if (d == null || m == null) { toast("Select a display and mode first."); return; }
        JSONArray profiles = readProfiles();
        if (profiles.length() >= MAX_PROFILES) { toast("All 12 profile slots are used. Delete one first."); return; }
        try {
            JSONObject p = new JSONObject();
            p.put("displayId", d.getDisplayId());
            p.put("displayName", d.getName());
            p.put("uniqueId", d.getUniqueId());
            p.put("modeId", m.getModeId());
            p.put("width", m.getPhysicalWidth());
            p.put("height", m.getPhysicalHeight());
            p.put("refresh", m.getRefreshRate());
            p.put("label", "Profile " + (profiles.length() + 1));
            profiles.put(p);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("items", profiles.toString()).apply();
            renderProfiles(); toast("Profile saved");
        } catch (Exception e) { toast("Could not save profile: " + e.getMessage()); }
    }

    private void renderProfiles() {
        if (profileContainer == null) return;
        profileContainer.removeAllViews();
        JSONArray profiles = readProfiles();
        profileText.setText(profiles.length() + " / " + MAX_PROFILES + " profile slots used");
        for (int i = 0; i < profiles.length(); i++) {
            final int slot = i;
            JSONObject p = profiles.optJSONObject(i); if (p == null) continue;
            String name = p.optString("label", "Profile " + (i + 1));
            String details = p.optString("displayName", "Display") + " · " + p.optInt("width") + " × " + p.optInt("height") + " · " + String.format(Locale.US, "%.2f Hz", p.optDouble("refresh"));
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView info = text(name + "\n" + details, 13, false, 0xFF263248);
            row.addView(info, new LinearLayout.LayoutParams(0, dp(58), 1));
            Button use = smallButton("Apply"); use.setOnClickListener(v -> applyProfile(slot)); row.addView(use);
            Button del = smallButton("Delete"); del.setOnClickListener(v -> deleteProfile(slot)); row.addView(del);
            profileContainer.addView(row);
        }
    }

    private void applyProfile(int slot) {
        JSONObject p = readProfiles().optJSONObject(slot); if (p == null) return;
        String unique = p.optString("uniqueId", "");
        int displayIndex = -1;
        for (int i = 0; i < displays.size(); i++) if (displays.get(i).getUniqueId().equals(unique)) displayIndex = i;
        if (displayIndex < 0) { toast("That display is not currently connected."); return; }
        displaySpinner.setSelection(displayIndex);
        Display d = displays.get(displayIndex);
        int modeId = p.optInt("modeId", -1); int modeIndex = -1;
        for (int i = 0; i < modes.size(); i++) if (modes.get(i).getModeId() == modeId) modeIndex = i;
        if (modeIndex < 0) { toast("That mode is no longer available on this display."); return; }
        modeSpinner.setSelection(modeIndex);
        applySelectedMode();
    }

    private void deleteProfile(int slot) {
        JSONArray old = readProfiles(), next = new JSONArray();
        for (int i = 0; i < old.length(); i++) if (i != slot) next.put(old.opt(i));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("items", next.toString()).apply();
        renderProfiles(); toast("Profile deleted");
    }

    private JSONArray readProfiles() {
        try { return new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString("items", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.isCtrlPressed() && event.isAltPressed() && keyCode >= KeyEvent.KEYCODE_1 && keyCode <= KeyEvent.KEYCODE_9) {
            applyProfile(keyCode - KeyEvent.KEYCODE_1); return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private Display selectedDisplay() { int i = displaySpinner == null ? -1 : displaySpinner.getSelectedItemPosition(); return i >= 0 && i < displays.size() ? displays.get(i) : null; }
    private Display.Mode selectedMode() { int i = modeSpinner == null ? -1 : modeSpinner.getSelectedItemPosition(); return i >= 0 && i < modes.size() ? modes.get(i) : null; }
    private void updateModeStatus() { Display.Mode m = selectedMode(); if (m != null && statusText != null) statusText.setText(String.format(Locale.US, "Selected: %d × %d at %.2f Hz", m.getPhysicalWidth(), m.getPhysicalHeight(), m.getRefreshRate())); }
    private void dismissPresentation() { if (externalPresentation != null) { try { externalPresentation.dismiss(); } catch (Exception ignored) {} externalPresentation = null; } }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams match() { return new LinearLayout.LayoutParams(-1, -2); }
    private View space(int height) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height))); return v; }
    private TextView text(String value, int size, boolean bold, int color) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(null, 1); t.setPadding(0, dp(4), 0, dp(4)); return t; }
    private void section(LinearLayout root, String value) { TextView t = text(value, 17, true, 0xFF172033); root.addView(t); }
    private Button button(String value) { Button b = new Button(this); b.setText(value); return b; }
    private Button smallButton(String value) { Button b = new Button(this); b.setText(value); b.setTextSize(12); return b; }

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int displayId) { refreshDisplays(); }
        @Override public void onDisplayRemoved(int displayId) { if (externalPresentation != null && externalPresentation.getDisplay().getDisplayId() == displayId) dismissPresentation(); refreshDisplays(); }
        @Override public void onDisplayChanged(int displayId) { refreshDisplays(); }
    };

    private static class DisplayPresentation extends Presentation {
        private TextView label;
        DisplayPresentation(Context context, Display display) { super(context, display); }
        @Override protected void onCreate(Bundle state) {
            super.onCreate(state);
            LinearLayout layout = new LinearLayout(getContext()); layout.setOrientation(LinearLayout.VERTICAL); layout.setGravity(Gravity.CENTER); layout.setPadding(24, 24, 24, 24); layout.setBackgroundColor(0xFF101827);
            TextView heading = new TextView(getContext()); heading.setText("Display HotKeys"); heading.setTextSize(25); heading.setTextColor(0xFFFFFFFF); layout.addView(heading);
            label = new TextView(getContext()); label.setText("External display presentation"); label.setTextSize(16); label.setTextColor(0xFFD8E0F0); label.setPadding(0, 16, 0, 0); layout.addView(label);
            setContentView(layout);
        }
        void setModeLabel(Display.Mode mode) { if (label != null) label.setText(String.format(Locale.US, "Requested app-window mode: %d × %d · %.2f Hz", mode.getPhysicalWidth(), mode.getPhysicalHeight(), mode.getRefreshRate())); }
    }

    private interface SelectionAction { void selected(int position); }
    private static class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        private final SelectionAction action;
        SimpleItemSelectedListener(SelectionAction action) { this.action = action; }
        @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { action.selected(position); }
        @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
    }
}
